<!-- start footer Area -->

	<script src="<?php echo base_url().'assets/web/js/osamabootjquery.min.js' ?>"></script>
	<script src="https://call.adtracks.com/adtracks/tracking.js" defer></script>
	<!-- Sweet Alerts Plugin Installation Start -->
	<script src="<?php echo base_url().'assets/web/js/sweetalert.min.js' ?>"></script>
	<!-- Sweet Alerts Plugin Installation End -->
	<script src="<?php echo base_url().'assets/web/js/jquery.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/web/js/vendor/jquery-2.2.4.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/web/js/popper.min.js' ?>" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="<?php echo base_url().'assets/web/js/vendor/bootstrap.min.js' ?>"></script>
	<!--script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script-->
	<script src="<?php echo base_url().'assets/web/js/osamaboot.min.js' ?>"></script>
	<!--script src="<?php //echo base_url().'assets/web/js/easing.min.js' ?>"> </script-->
	<!--script src="<?php //echo base_url().'assets/web/js/hoverIntent.js' ?>"></script-->
	<script src="<?php echo base_url().'assets/web/js/superfish.min.js'?> "></script>
	<script src="<?php echo base_url().'assets/web/js/jquery.ajaxchimp.min.js'?> "></script>
	<script src="<?php echo base_url().'assets/web/js/jquery.magnific-popup.min.js'?> "></script>
	<script src="<?php echo base_url().'assets/web/js/owl.carousel.min.js'?> "></script>
	<script src="<?php echo base_url().'assets/web/js/jquery.sticky.min.js'?> "></script>
	<!--script src="<?php //echo base_url().'assets/web/js/jquery.nice-select.min.js '?> "></script-->
	<script src="<?php echo base_url().'assets/web/js/parallax.min.js'?> "></script>
	<!--script src="<?php //echo base_url().'assets/web/js/waypoints.min.js'?> "></script-->
	<script src="<?php echo base_url().'assets/web/js/jquery.counterup.min.js'?> "></script>
	<script src="<?php echo base_url().'assets/web/js/main.min.js'?> "></script>
	<!--script type="text/javascript" src="<?php //echo base_url().'assets/web/js/calcul.js'?>"></script-->
	<!-- Start of HubSpot Embed Code -->
	

</body>
</html>
