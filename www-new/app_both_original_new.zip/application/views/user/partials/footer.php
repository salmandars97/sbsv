
 <!-- footer content -->
        <footer>
          <div class="pull-right">
            Developed By<a href="https://stepbystepvisas.com/"> Step-By-Step Visas</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

   <!-- jQuery -->
    <script src="<?php echo base_url().'assets/admin/vendors/jquery/dist/jquery.min.js ' ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url().'assets/admin/vendors/bootstrap/dist/js/bootstrap.min.js ' ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url().'assets/admin/vendors/fastclick/lib/fastclick.js ' ?>"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url().'assets/admin/vendors/nprogress/nprogress.js ' ?>"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url().'assets/admin/vendors/iCheck/icheck.min.js ' ?>"></script>
   <!-- Datatables -->
    <script src="<?php echo base_url().'assets/plugins/datatables/js/jquery.dataTables.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/plugins/datatables/js/dataTables.buttons.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/plugins/datatables/js/buttons.flash.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/plugins/datatables/js/jszip.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/plugins/datatables/js/buttons.html5.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/plugins/datatables/js/buttons.print.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/plugins/datatables/js/responsive.bootstrap.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/plugins/datatables/js/dataTables.responsive.min.js' ?>"></script>
	<script src="<?php echo base_url().'assets/plugins/datatables/js/buttons.colVis.min.js' ?>"></script>
    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url().'assets/admin/build/js/custom.min.js ' ?>"></script>

  </body>
</html>