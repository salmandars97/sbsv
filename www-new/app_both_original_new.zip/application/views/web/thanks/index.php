
			  
			  <br><br><br><br>
			  
			  <div style="text-align: center; " class="max-gap">
			      <center><img style="width: 200px;" src="<?php echo base_url().'assets_clone/web/img/thanks.png'?>" alt="Thankyou" class="img-responsive"></center><br><br>
			      <h1>You're Awesome!</h1><br>
			      <h4>Thank you for your Information! A specialist will contact you shortly.</h4><br>
			      <h4>Remember! We are here to help.</h4>
			  </div>
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			 