<style>
.fixed-height {
    height: 450px; 
    overflow: hidden; 
}
</style>
        
        <!-- Main Wrapper-->
        <main class="wrapper">
            <!-- Page Header -->
            <div class="wptb-page-heading" style="background-image: url('assets_clone/img/background/page-header-bg.jpg');">
                <div class="container">
                    <div class="wptb-item--inner">
                        <h2 class="wptb-item--title ">Thank You</h2>
                        <div class="wptb-breadcrumb-wrap">
                            <ul class="wptb-breadcrumb">
                                <li><a href="#">Home</a></li>
                                <li><a href="#">Pages</a></li>
                                <li><span>Thank You</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            

            <section class="home-about-area section-gap" id="about">
				<div class="container-fluid">				
					<div class="row justify-content-center align-items-center">
						 <br><br><br><br>
			  
            			  <div style="text-align: center; " class="max-gap">
            			      <center><img style="width: 200px;" src="<?php echo base_url().'assets_clone/web/img/thanks.png'?>" alt="Thankyou" class="img-responsive"></center><br><br>
            			      <h1>You're Awesome!</h1><br>
            			      <h4>Thank you for your Information! A specialist will contact you shortly.</h4><br>
            			      <h4>Remember! We are here to help.</h4>
            			  </div>
					</div>
				</div>	
			</section>	
									
        </main>
