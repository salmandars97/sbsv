<!-- start banner Area -->
			<section class="banner-ar relative" id="home">
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
							 <?php echo  $title; ?>
							</h1>
							<p class="text-white link-nav">
								<a href="<?= base_url().'Home' ?>">Home</a>
								  <span class="lnr lnr-arrow-right"></span>
									  <a href="#"> <?= $title ?></a></p>
						</div>
					</div>
				</div>
			</section>
			<!-- End banner Area -->

			<!-- Start about-top Area -->
			<section class="about-top-area section-gap">
				<div class="container">
					<div class="row align-items-start justify-content-center">
						<div class="col-lg-8 about-top-left">

							<?php echo  $text; ?>



						</div>

					</div>
				</div>
			</section>
			<!-- End about-top Area -->
