
			  <br><br>
			  <div class="max-gap">
			  <div style="text-align: center; " class="section-gap">
			      <center><img style="width: 180px;" src="<?php echo base_url().'assets/web/img/thumbup.png'?>" alt="Thankyou" class=" img-responsive"></center><br><br>
			      <h1>Great Decision!!</h1><br>
			      <h4>You will now receive updates and/or changes to Government Immigration policies and procedures.</h4><br>
			      <h4>Remember!! We are here to Help.</h4>
			  </div>
			  </div>
			  
			  
			  
			  
			  
			  
			  
			  
		