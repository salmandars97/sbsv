<section class="callto-area max-gap relative" style="margin-top:40px;">
				<div class="overlay overlay-bg"></div>	
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-12">
							<h1 class="text-white">A world of opportunities awaits you! </h1>
							<p></p>
							<a class="primary-btn" href="<?php echo base_url().'Home '?>">Request A Consultation</a>
						</div>
					</div>
				</div>	
			</section>