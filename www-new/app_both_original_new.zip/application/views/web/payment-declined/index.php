

			<!-- start banner Area -->
			<section class="banner-ar relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								Transaction Declined				
							</h1>	
							<p class="text-white link-nav"><a href="<?php echo base_url().'Home '?>">Home</a>  <span class="lnr lnr-arrow-right"></span>  <a href="<?php echo base_url().'Payment_declined'?>">Transaction Declined</a></p>
						</div>											
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<section class="home-about-area section-gap" id="about">
				<div class="container-fluid">				
					<div class="row justify-content-center align-items-center">
						<div class="col-lg-6 no-padding home-about-left">
							<img class="img-fluid" src="<?php echo base_url().'assets/web/img/online-payment-tem.jpg'?>" alt="">
						</div>
						<div class="col-lg-6 no-padding home-about-right">
							<h1>Transaction Declined</h1>
							<p>Oops! something may have gone wrong, Please try again using a different card.</p>
							
		<p>Do contact your immigration specialist should the problem persist. Remember! we are here to Help.</strong></p>
		<p><img src="<?php echo base_url().'assets/web/img/payment.jpg'?>" width="157" height="25" alt=""></p>
		</div>
					</div>
				</div>	
			</section>	
