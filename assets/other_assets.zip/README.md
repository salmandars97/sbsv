`$ npm update`
